hello <- function() {
  "hello"
}
