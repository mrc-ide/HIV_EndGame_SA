context_cache <- new.env(parent = emptyenv())
